<?php
// includes/scoring.php - assessment criteria & scoring (weights total = 100)
$CRITERIA = [
    ['key' => 'tasks_projects',     'label' => 'Tasks / Projects',       'weight' => 10],
    ['key' => 'health_safety',      'label' => 'Health / Safety',        'weight' => 10],
    ['key' => 'theory',             'label' => 'Theory',                 'weight' => 10],
    ['key' => 'report_presentation','label' => 'Report Presentation',    'weight' => 15],
    ['key' => 'language_clarity',   'label' => 'Language Clarity',       'weight' => 10],
    ['key' => 'lifelong_learning',  'label' => 'Lifelong Learning',      'weight' => 15],
    ['key' => 'project_management', 'label' => 'Project Management',     'weight' => 15],
    ['key' => 'time_management',    'label' => 'Time Management',        'weight' => 15],
];

function compute_score($marks, $criteria) {
    $total = 0.0;
    foreach ($criteria as $c) {
        $v = isset($marks[$c['key']]) ? (float)$marks[$c['key']] : 0.0;
        $total += ($v * $c['weight']) / 100.0;
    }
    return round($total, 2);
}

function grade_for($score) {
    if ($score >= 80) return 'A';
    if ($score >= 70) return 'B';
    if ($score >= 60) return 'C';
    if ($score >= 50) return 'D';
    return 'F';
}

function validate_marks($input, $criteria) {
    $clean = [];
    foreach ($criteria as $c) {
        if (!isset($input[$c['key']]) || $input[$c['key']] === '') {
            return [false, "Missing mark for {$c['label']}", null];
        }
        $v = $input[$c['key']];
        if (!is_numeric($v)) {
            return [false, "Mark for {$c['label']} must be numeric", null];
        }
        $v = (float)$v;
        if ($v < 0 || $v > 100) {
            return [false, "Mark for {$c['label']} must be between 0 and 100", null];
        }
        $clean[$c['key']] = $v;
    }
    return [true, '', $clean];
}
?>

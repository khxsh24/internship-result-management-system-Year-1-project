<?php
// includes/auth.php - session helpers
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login($allowed_roles = null) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit;
    }
    if ($allowed_roles !== null && !in_array($_SESSION['role'], $allowed_roles, true)) {
        header("Location: dashboard.php");
        exit;
    }
}

function current_user() {
    if (!isset($_SESSION['user_id'])) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['name'] ?? '',
        'email' => $_SESSION['email'] ?? '',
        'role' => $_SESSION['role'] ?? 'assessor',
    ];
}

function logout_user() {
    $_SESSION = [];
    session_destroy();
}

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>

<?php
// includes/shell.php - render sidebar + topbar. $page sets active link.
$user = current_user();
$role = $user['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($PAGE_TITLE ?? 'IRMS') ?> &middot; IRMS</title>
  <link rel="stylesheet" href="css/styles.css" />
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h2>IRMS</h2>
    <nav class="nav">
      <a href="dashboard.php"   class="<?= $page==='dashboard'?'active':'' ?>">Dashboard</a>
      <?php if ($role === 'admin'): ?>
        <a href="students.php"    class="<?= $page==='students'?'active':'' ?>">Students</a>
        <a href="internships.php" class="<?= $page==='internships'?'active':'' ?>">Internships</a>
      <?php endif; ?>
      <?php if ($role === 'assessor'): ?>
        <a href="assessments.php" class="<?= $page==='assessments'?'active':'' ?>">My Assessments</a>
      <?php endif; ?>
      <a href="results.php"    class="<?= $page==='results'?'active':'' ?>">Results</a>
      <a href="logout.php">Sign out</a>
    </nav>
  </aside>
  <main class="main">
    <div class="topbar">
      <div></div>
      <div class="user">
        Signed in as <strong><?= e($user['name']) ?></strong>
        &middot; <?= e(ucfirst($role)) ?>
      </div>
    </div>

<?php
require_once 'db.php';
require_once 'includes/auth.php';
require_login();
$page = 'dashboard';
$PAGE_TITLE = 'Dashboard';

$user = current_user();
$stats = [];

if ($user['role'] === 'admin') {
    $stats['Students']    = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM students"))[0];
    $stats['Internships'] = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM internships"))[0];
    $stats['Assessors']   = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM users WHERE role='assessor'"))[0];
    $stats['Assessments Done'] = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM assessments"))[0];
} else {
    $uid = (int)$user['id'];
    $stats['Assigned Students'] = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM internships WHERE assessor_id=$uid"))[0];
    $stats['Assessments Done']  = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM assessments WHERE assessor_id=$uid"))[0];
    $stats['Pending']           = $stats['Assigned Students'] - $stats['Assessments Done'];
    if ($stats['Pending'] < 0) $stats['Pending'] = 0;
}

include 'includes/shell.php';
?>
<div class="page-header">
  <h1 class="page-title">Welcome back, <?= e($user['name']) ?></h1>
  <p class="page-subtitle"><?= $user['role']==='admin' ? 'System overview' : 'Your assessment overview' ?></p>
</div>

<div class="stat-grid">
  <?php foreach ($stats as $label => $val): ?>
    <div class="stat">
      <div class="stat-label"><?= e($label) ?></div>
      <div class="stat-value"><?= (int)$val ?></div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card">
  <h3 style="margin-top:0;">Quick links</h3>
  <p>
    <?php if ($user['role'] === 'admin'): ?>
      <a class="btn btn-primary" href="students.php">Manage students</a>
      <a class="btn btn-secondary" href="internships.php">Manage internships</a>
    <?php else: ?>
      <a class="btn btn-primary" href="assessments.php">Go to my assessments</a>
    <?php endif; ?>
    <a class="btn btn-secondary" href="results.php">View results</a>
  </p>
</div>
<?php include 'includes/shell_end.php'; ?>

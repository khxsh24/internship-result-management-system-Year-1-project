<?php
// index.php - login page
require_once 'db.php';
require_once 'includes/auth.php';

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';
$email_val = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $email_val = $email;

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email.';
    } else {
        $stmt = mysqli_prepare($conn, "SELECT id, name, email, password, role FROM users WHERE email = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);

        if ($user && $user['password'] === $password) {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['name']    = $user['name'];
            $_SESSION['email']   = $user['email'];
            $_SESSION['role']    = $user['role'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sign in &middot; IRMS</title>
  <link rel="stylesheet" href="css/styles.css" />
</head>
<body class="login-page">
  <main class="login-card">
    <div class="login-logo"><div class="login-logo-mark">IR</div></div>
    <h1 class="login-title">Internship Result Management</h1>
    <p class="login-subtitle">University Assessment Portal</p>

    <?php if ($error): ?>
      <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php" novalidate>
      <div class="form-group">
        <label class="form-label" for="email">Email address</label>
        <input class="form-input" type="email" id="email" name="email"
               value="<?= e($email_val) ?>" required autocomplete="username" />
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Password</label>
        <input class="form-input" type="password" id="password" name="password"
               required autocomplete="current-password" />
      </div>
      <button type="submit" class="btn btn-primary btn-block">Sign in</button>

      <div class="login-hint">
        <strong>Demo accounts</strong><br />
        Admin &mdash; <code>admin@uni.edu</code> / <code>admin123</code><br />
        Assessor &mdash; <code>sarah@uni.edu</code> / <code>pass123</code><br />
        Assessor &mdash; <code>ahmad@uni.edu</code> / <code>pass123</code>
      </div>
    </form>
  </main>
</body>
</html>

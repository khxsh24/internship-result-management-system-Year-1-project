<?php
require_once 'db.php';
require_once 'includes/auth.php';
require_login(['admin']);
$page = 'students';
$PAGE_TITLE = 'Students';

$msg = ''; $err = '';

// Handle DELETE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    $stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    if (mysqli_stmt_execute($stmt)) $msg = "Student deleted.";
    else $err = "Failed to delete student.";
    mysqli_stmt_close($stmt);
}

// Handle INSERT or UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array(($_POST['action'] ?? ''), ['create','update'], true)) {
    $student_id = trim($_POST['student_id'] ?? '');
    $name       = trim($_POST['name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $programme  = trim($_POST['programme'] ?? '');
    $year       = (int)($_POST['year'] ?? 0);

    if ($student_id==='' || $name==='' || $email==='' || $programme==='' || $year<1 || $year>10) {
        $err = "All fields are required and year must be 1-10.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err = "Invalid email.";
    } else {
        if ($_POST['action'] === 'create') {
            $stmt = mysqli_prepare($conn,
              "INSERT INTO students (student_id, name, email, programme, year) VALUES (?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, 'ssssi', $student_id, $name, $email, $programme, $year);
            if (mysqli_stmt_execute($stmt)) $msg = "Student added.";
            else $err = "Failed to add student (duplicate ID?).";
            mysqli_stmt_close($stmt);
        } else {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = mysqli_prepare($conn,
              "UPDATE students SET student_id=?, name=?, email=?, programme=?, year=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssssii', $student_id, $name, $email, $programme, $year, $id);
            if (mysqli_stmt_execute($stmt)) $msg = "Student updated.";
            else $err = "Failed to update student.";
            mysqli_stmt_close($stmt);
        }
    }
}

// Edit mode
$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
}

$students = mysqli_query($conn, "SELECT * FROM students ORDER BY student_id");

include 'includes/shell.php';
?>
<div class="page-header">
  <h1 class="page-title">Students</h1>
  <p class="page-subtitle">Manage student records</p>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>

<div class="card">
  <h3 style="margin-top:0;"><?= $edit ? 'Edit Student' : 'Add Student' ?></h3>
  <form method="POST" action="students.php">
    <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
      <div class="form-group">
        <label class="form-label">Student ID</label>
        <input class="form-input" name="student_id" required value="<?= e($edit['student_id'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Name</label>
        <input class="form-input" name="name" required value="<?= e($edit['name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Email</label>
        <input class="form-input" type="email" name="email" required value="<?= e($edit['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Programme</label>
        <input class="form-input" name="programme" required value="<?= e($edit['programme'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Year</label>
        <input class="form-input" type="number" name="year" min="1" max="10" required value="<?= e($edit['year'] ?? '') ?>">
      </div>
    </div>
    <button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Add student' ?></button>
    <?php if ($edit): ?><a class="btn btn-secondary" href="students.php">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="table-wrap"><div class="table-scroll">
<table>
  <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Programme</th><th>Year</th><th>Actions</th></tr></thead>
  <tbody>
  <?php if (mysqli_num_rows($students) === 0): ?>
    <tr><td colspan="6" class="empty"><div class="empty-icon">&#9787;</div>No students yet.</td></tr>
  <?php else: while ($s = mysqli_fetch_assoc($students)): ?>
    <tr>
      <td><strong><?= e($s['student_id']) ?></strong></td>
      <td><?= e($s['name']) ?></td>
      <td><?= e($s['email']) ?></td>
      <td><?= e($s['programme']) ?></td>
      <td><?= (int)$s['year'] ?></td>
      <td>
        <div class="table-actions">
          <a class="btn btn-sm btn-secondary" href="students.php?edit=<?= (int)$s['id'] ?>">Edit</a>
          <form method="POST" action="students.php" onsubmit="return confirmAction('Delete this student?');" style="display:inline;">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
          </form>
        </div>
      </td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div></div>
<?php include 'includes/shell_end.php'; ?>

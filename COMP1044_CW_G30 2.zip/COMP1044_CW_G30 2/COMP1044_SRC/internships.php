<?php
require_once 'db.php';
require_once 'includes/auth.php';
require_login(['admin']);
$page = 'internships';
$PAGE_TITLE = 'Internships';

$msg=''; $err='';

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='delete') {
    $id = (int)$_POST['id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM internships WHERE id=?");
    mysqli_stmt_bind_param($stmt,'i',$id);
    if (mysqli_stmt_execute($stmt)) $msg="Internship deleted."; else $err="Delete failed.";
    mysqli_stmt_close($stmt);
}

if ($_SERVER['REQUEST_METHOD']==='POST' && in_array(($_POST['action'] ?? ''), ['create','update'], true)) {
    $student_id  = (int)($_POST['student_id'] ?? 0);
    $company     = trim($_POST['company_name'] ?? '');
    $position    = trim($_POST['position'] ?? '');
    $start       = $_POST['start_date'] ?? '';
    $end         = $_POST['end_date'] ?? '';
    $assessor    = ($_POST['assessor_id'] ?? '') === '' ? null : (int)$_POST['assessor_id'];

    if (!$student_id || $company==='' || $position==='' || $start==='' || $end==='') {
        $err = "All fields except assessor are required.";
    } elseif (strtotime($end) < strtotime($start)) {
        $err = "End date must be after start date.";
    } else {
        if ($_POST['action']==='create') {
            $stmt = mysqli_prepare($conn,
              "INSERT INTO internships (student_id, company_name, position, start_date, end_date, assessor_id) VALUES (?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt,'issssi', $student_id, $company, $position, $start, $end, $assessor);
            if (mysqli_stmt_execute($stmt)) $msg="Internship added."; else $err="Insert failed.";
            mysqli_stmt_close($stmt);
        } else {
            $id = (int)$_POST['id'];
            $stmt = mysqli_prepare($conn,
              "UPDATE internships SET student_id=?, company_name=?, position=?, start_date=?, end_date=?, assessor_id=? WHERE id=?");
            mysqli_stmt_bind_param($stmt,'issssii', $student_id, $company, $position, $start, $end, $assessor, $id);
            if (mysqli_stmt_execute($stmt)) $msg="Internship updated."; else $err="Update failed.";
            mysqli_stmt_close($stmt);
        }
    }
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = mysqli_prepare($conn,"SELECT * FROM internships WHERE id=?");
    mysqli_stmt_bind_param($stmt,'i',$id);
    mysqli_stmt_execute($stmt);
    $edit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
}

$students  = mysqli_query($conn,"SELECT id, student_id, name FROM students ORDER BY student_id");
$assessors = mysqli_query($conn,"SELECT id, name FROM users WHERE role='assessor' ORDER BY name");
$rows      = mysqli_query($conn,
    "SELECT i.*, s.student_id AS s_code, s.name AS s_name, u.name AS a_name
       FROM internships i
       JOIN students s ON s.id = i.student_id
       LEFT JOIN users u ON u.id = i.assessor_id
       ORDER BY i.id DESC");

include 'includes/shell.php';
?>
<div class="page-header">
  <h1 class="page-title">Internships</h1>
  <p class="page-subtitle">Assign students to companies and assessors</p>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>

<div class="card">
  <h3 style="margin-top:0;"><?= $edit ? 'Edit Internship' : 'Add Internship' ?></h3>
  <form method="POST" action="internships.php">
    <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
    <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><?php endif; ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;">
      <div class="form-group">
        <label class="form-label">Student</label>
        <select class="form-select" name="student_id" required>
          <option value="">-- Select --</option>
          <?php mysqli_data_seek($students,0); while ($s=mysqli_fetch_assoc($students)): ?>
            <option value="<?= (int)$s['id'] ?>" <?= ($edit && (int)$edit['student_id']===(int)$s['id'])?'selected':'' ?>>
              <?= e($s['student_id'].' - '.$s['name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Company</label>
        <input class="form-input" name="company_name" required value="<?= e($edit['company_name'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Position</label>
        <input class="form-input" name="position" required value="<?= e($edit['position'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Start date</label>
        <input class="form-input" type="date" name="start_date" required value="<?= e($edit['start_date'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">End date</label>
        <input class="form-input" type="date" name="end_date" required value="<?= e($edit['end_date'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Assessor</label>
        <select class="form-select" name="assessor_id">
          <option value="">-- Unassigned --</option>
          <?php mysqli_data_seek($assessors,0); while ($a=mysqli_fetch_assoc($assessors)): ?>
            <option value="<?= (int)$a['id'] ?>" <?= ($edit && (int)$edit['assessor_id']===(int)$a['id'])?'selected':'' ?>>
              <?= e($a['name']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
    <button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Add internship' ?></button>
    <?php if ($edit): ?><a class="btn btn-secondary" href="internships.php">Cancel</a><?php endif; ?>
  </form>
</div>

<div class="table-wrap"><div class="table-scroll">
<table>
  <thead><tr><th>Student</th><th>Company</th><th>Position</th><th>Period</th><th>Assessor</th><th>Actions</th></tr></thead>
  <tbody>
  <?php if (mysqli_num_rows($rows)===0): ?>
    <tr><td colspan="6" class="empty"><div class="empty-icon">&#9874;</div>No internships yet.</td></tr>
  <?php else: while($r=mysqli_fetch_assoc($rows)): ?>
    <tr>
      <td><strong><?= e($r['s_code']) ?></strong><br><span style="color:var(--text-muted);font-size:13px;"><?= e($r['s_name']) ?></span></td>
      <td><?= e($r['company_name']) ?></td>
      <td><?= e($r['position']) ?></td>
      <td><?= e($r['start_date']) ?> &rarr; <?= e($r['end_date']) ?></td>
      <td><?= $r['a_name'] ? e($r['a_name']) : '<span class="badge badge-warning">Unassigned</span>' ?></td>
      <td>
        <div class="table-actions">
          <a class="btn btn-sm btn-secondary" href="internships.php?edit=<?= (int)$r['id'] ?>">Edit</a>
          <form method="POST" action="internships.php" onsubmit="return confirmAction('Delete this internship?');" style="display:inline;">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
          </form>
        </div>
      </td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div></div>
<?php include 'includes/shell_end.php'; ?>

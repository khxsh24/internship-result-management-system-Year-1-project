# COMP1044 Coursework — Internship Result Management System (IRMS)

A pure **PHP + MySQL** web application. No frameworks. No localStorage.
Styled with hand-written CSS only (no Tailwind / Bootstrap).

## Folder structure
```
COMP1044_CW/
├── index.php              # Login (POST -> session_start)
├── dashboard.php          # Role-aware dashboard
├── students.php           # Admin: students CRUD
├── internships.php        # Admin: internships CRUD
├── assessments.php        # Assessor: enter / edit marks
├── results.php            # Ranked results view
├── logout.php
├── db.php                 # mysqli_connect to COMP1044_CW
├── COMP1044_database.sql  # CREATE DATABASE + tables + demo data
├── includes/
│   ├── auth.php           # session helpers + require_login()
│   ├── scoring.php        # 8 criteria + weights + 0-100 validation
│   ├── shell.php          # sidebar + topbar layout
│   └── shell_end.php
├── css/styles.css         # pure CSS
└── js/app.js              # tiny helpers (live score, confirm)
```

## Setup (XAMPP / WAMP / MAMP)

1. Copy this whole folder into your web root, e.g.
   `C:\xampp\htdocs\COMP1044_CW_G1\` (rename folder to your group number).
2. Start **Apache** and **MySQL** from the XAMPP control panel.
3. Open `http://localhost/phpmyadmin`, click **Import**, choose
   `COMP1044_database.sql`, and run it. This creates the database and
   loads demo data.
4. If your MySQL `root` user has a password, edit `db.php` and update
   `$DB_PASS`.
5. Visit `http://localhost/COMP1044_CW_G1/` (or whatever you named the folder).

## Demo accounts
| Role     | Email             | Password   |
|----------|-------------------|------------|
| Admin    | admin@uni.edu     | admin123   |
| Assessor | sarah@uni.edu     | pass123    |
| Assessor | ahmad@uni.edu     | pass123    |

## Assessment weightages (total = 100%)
| Criterion              | Weight |
|------------------------|--------|
| Tasks / Projects       | 10%    |
| Health / Safety        | 10%    |
| Theory                 | 10%    |
| Report Presentation    | 15%    |
| Language Clarity       | 10%    |
| Lifelong Learning      | 15%    |
| Project Management     | 15%    |
| Time Management        | 15%    |

Server-side validation (in `includes/scoring.php` -> `validate_marks`)
rejects any mark that is missing, non-numeric, < 0, or > 100.

## Database
- Tables: `users`, `students`, `internships`, `assessments`
- Foreign keys with `ON DELETE CASCADE` (and `SET NULL` for assessor).
- `CHECK` constraints enforce 0–100 marks at the DB layer too.

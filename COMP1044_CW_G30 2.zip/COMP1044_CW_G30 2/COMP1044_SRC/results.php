<?php
require_once 'db.php';
require_once 'includes/auth.php';
require_once 'includes/scoring.php';
require_login();
$page = 'results';
$PAGE_TITLE = 'Results';

$user = current_user();
$isAdmin = $user['role']==='admin';

$where = '';
$params = [];
$types = '';
if (!$isAdmin) {
    $where = 'WHERE a.assessor_id = ?';
    $types = 'i';
    $params[] = (int)$user['id'];
}

$sql = "SELECT a.*, s.student_id AS s_code, s.name AS s_name, s.programme,
               i.company_name, u.name AS assessor_name
          FROM assessments a
          JOIN students s    ON s.id = a.student_id
          LEFT JOIN internships i ON i.student_id = a.student_id AND i.assessor_id = a.assessor_id
          JOIN users u       ON u.id = a.assessor_id
          $where
       ORDER BY a.final_score DESC";

if ($params) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $rows = mysqli_stmt_get_result($stmt);
} else {
    $rows = mysqli_query($conn, $sql);
}

include 'includes/shell.php';
?>
<div class="page-header">
  <h1 class="page-title"><?= $isAdmin ? 'All Results' : "My Students' Results" ?></h1>
  <p class="page-subtitle">Final scores ranked from highest to lowest</p>
</div>

<div class="table-wrap"><div class="table-scroll">
<table>
  <thead>
    <tr>
      <th>Rank</th><th>Student</th><th>Programme</th><th>Company</th>
      <?php if ($isAdmin): ?><th>Assessor</th><?php endif; ?>
      <th>Score</th><th>Grade</th><th>Comments</th>
    </tr>
  </thead>
  <tbody>
  <?php if (mysqli_num_rows($rows)===0): ?>
    <tr><td colspan="<?= $isAdmin?8:7 ?>" class="empty"><div class="empty-icon">&#9733;</div>No assessments yet.</td></tr>
  <?php else: $rank=1; while ($r=mysqli_fetch_assoc($rows)): ?>
    <tr>
      <td><strong>#<?= $rank++ ?></strong></td>
      <td><strong><?= e($r['s_code']) ?></strong><br><span style="color:var(--text-muted);font-size:13px;"><?= e($r['s_name']) ?></span></td>
      <td><?= e($r['programme']) ?></td>
      <td><?= e($r['company_name'] ?? '-') ?></td>
      <?php if ($isAdmin): ?><td><?= e($r['assessor_name']) ?></td><?php endif; ?>
      <td><strong style="color:var(--primary);"><?= e(number_format((float)$r['final_score'],2)) ?></strong></td>
      <td><span class="badge badge-success"><?= e(grade_for((float)$r['final_score'])) ?></span></td>
      <td style="max-width:280px;color:var(--text-muted);font-size:13px;"><?= e($r['comments'] ?? '') ?></td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div></div>
<?php include 'includes/shell_end.php'; ?>

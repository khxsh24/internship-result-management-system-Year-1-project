<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "root";
$DB_NAME = "COMP1044_CW";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, 8889);
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");
?>
<?php
require_once 'db.php';
require_once 'includes/auth.php';
require_once 'includes/scoring.php';
require_login(['assessor']);
$page = 'assessments';
$PAGE_TITLE = 'My Assessments';

$user = current_user();
$uid  = (int)$user['id'];

$msg=''; $err='';

// DELETE
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='delete') {
    $id = (int)$_POST['id'];
    $stmt = mysqli_prepare($conn,"DELETE FROM assessments WHERE id=? AND assessor_id=?");
    mysqli_stmt_bind_param($stmt,'ii',$id,$uid);
    if (mysqli_stmt_execute($stmt)) $msg="Assessment deleted."; else $err="Delete failed.";
    mysqli_stmt_close($stmt);
}

// SAVE (insert or update)
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='save') {
    $student_id = (int)($_POST['student_id'] ?? 0);

    // Verify the student is assigned to this assessor
    $check = mysqli_prepare($conn,"SELECT id FROM internships WHERE student_id=? AND assessor_id=?");
    mysqli_stmt_bind_param($check,'ii',$student_id,$uid);
    mysqli_stmt_execute($check);
    $ok = mysqli_fetch_assoc(mysqli_stmt_get_result($check));
    mysqli_stmt_close($check);

    if (!$ok) {
        $err = "You are not assigned to this student.";
    } else {
        list($valid, $vErr, $marks) = validate_marks($_POST, $CRITERIA);
        if (!$valid) {
            $err = $vErr;
        } else {
            $score    = compute_score($marks, $CRITERIA);
            $comments = trim($_POST['comments'] ?? '');

            // Does an assessment already exist?
            $find = mysqli_prepare($conn,"SELECT id FROM assessments WHERE student_id=? AND assessor_id=?");
            mysqli_stmt_bind_param($find,'ii',$student_id,$uid);
            mysqli_stmt_execute($find);
            $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($find));
            mysqli_stmt_close($find);

            if ($existing) {
                $stmt = mysqli_prepare($conn, "UPDATE assessments SET
                    tasks_projects=?, health_safety=?, theory=?, report_presentation=?,
                    language_clarity=?, lifelong_learning=?, project_management=?, time_management=?,
                    final_score=?, comments=?
                    WHERE id=?");
                mysqli_stmt_bind_param($stmt,'dddddddddsi',
                    $marks['tasks_projects'], $marks['health_safety'], $marks['theory'],
                    $marks['report_presentation'], $marks['language_clarity'],
                    $marks['lifelong_learning'], $marks['project_management'],
                    $marks['time_management'], $score, $comments, $existing['id']);
                if (mysqli_stmt_execute($stmt)) $msg="Assessment updated."; else $err="Update failed.";
                mysqli_stmt_close($stmt);
            } else {
                $stmt = mysqli_prepare($conn, "INSERT INTO assessments
                    (student_id, assessor_id, tasks_projects, health_safety, theory,
                     report_presentation, language_clarity, lifelong_learning,
                     project_management, time_management, final_score, comments)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt,'iiddddddddds',
                    $student_id, $uid,
                    $marks['tasks_projects'], $marks['health_safety'], $marks['theory'],
                    $marks['report_presentation'], $marks['language_clarity'],
                    $marks['lifelong_learning'], $marks['project_management'],
                    $marks['time_management'], $score, $comments);
                if (mysqli_stmt_execute($stmt)) $msg="Assessment saved."; else $err="Insert failed: ".mysqli_error($conn);
                mysqli_stmt_close($stmt);
            }
        }
    }
}

// Load assigned students with their existing assessment (if any)
$q = mysqli_prepare($conn,
    "SELECT s.id AS sid, s.student_id AS s_code, s.name AS s_name, s.programme,
            i.company_name, i.position,
            a.id AS a_id, a.tasks_projects, a.health_safety, a.theory,
            a.report_presentation, a.language_clarity, a.lifelong_learning,
            a.project_management, a.time_management, a.final_score, a.comments
       FROM internships i
       JOIN students s ON s.id = i.student_id
       LEFT JOIN assessments a ON a.student_id = s.id AND a.assessor_id = ?
      WHERE i.assessor_id = ?
   ORDER BY s.student_id");
mysqli_stmt_bind_param($q,'ii',$uid,$uid);
mysqli_stmt_execute($q);
$assigned = mysqli_stmt_get_result($q);

// If editing, find selected student
$editId = isset($_GET['student']) ? (int)$_GET['student'] : 0;
$editRow = null;
if ($editId) {
    $stmt = mysqli_prepare($conn,
        "SELECT s.id AS sid, s.student_id AS s_code, s.name AS s_name, s.programme,
                i.company_name,
                a.tasks_projects, a.health_safety, a.theory, a.report_presentation,
                a.language_clarity, a.lifelong_learning, a.project_management,
                a.time_management, a.comments
           FROM internships i
           JOIN students s ON s.id = i.student_id
           LEFT JOIN assessments a ON a.student_id = s.id AND a.assessor_id = ?
          WHERE i.assessor_id = ? AND s.id = ?");
    mysqli_stmt_bind_param($stmt,'iii',$uid,$uid,$editId);
    mysqli_stmt_execute($stmt);
    $editRow = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
}

include 'includes/shell.php';
?>
<div class="page-header">
  <h1 class="page-title">My Assigned Students</h1>
  <p class="page-subtitle">Enter and manage internship assessments</p>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>

<?php if ($editRow): ?>
<div class="card">
  <h3 style="margin-top:0;">
    Assessment &mdash; <?= e($editRow['s_name']) ?>
    <span style="font-weight:normal;color:var(--text-muted);font-size:14px;">
      (<?= e($editRow['s_code']) ?> &middot; <?= e($editRow['programme']) ?> &middot; <?= e($editRow['company_name']) ?>)
    </span>
  </h3>

  <form method="POST" action="assessments.php">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="student_id" value="<?= (int)$editRow['sid'] ?>">

    <div class="assessment-grid">
    <?php foreach ($CRITERIA as $c): ?>
      <div class="assess-row">
        <div class="assess-criteria"><?= e($c['label']) ?></div>
        <div class="assess-weight">Weight <?= (int)$c['weight'] ?>%</div>
        <input class="form-input assess-input" type="number" min="0" max="100" step="0.01"
               name="<?= e($c['key']) ?>"
               value="<?= e($editRow[$c['key']] ?? '') ?>"
               required>
        <div class="assess-contrib" data-contrib="<?= e($c['key']) ?>">0.00</div>
      </div>
    <?php endforeach; ?>
    </div>

    <div class="score-summary">
      <div>
        <div class="score-summary-label">Final Score (auto)</div>
        <div class="score-summary-value" id="finalScore">0.00</div>
      </div>
      <div class="score-grade" id="gradeLabel">F</div>
    </div>

    <div class="form-group" style="margin-top:14px;">
      <label class="form-label">Comments / Feedback</label>
      <textarea class="form-textarea" name="comments" rows="4"><?= e($editRow['comments'] ?? '') ?></textarea>
    </div>

    <button class="btn btn-primary" type="submit">Save assessment</button>
    <a class="btn btn-secondary" href="assessments.php">Cancel</a>
  </form>
</div>
<?php endif; ?>

<div class="table-wrap"><div class="table-scroll">
<table>
  <thead><tr><th>Student ID</th><th>Name</th><th>Programme</th><th>Company</th><th>Status</th><th>Actions</th></tr></thead>
  <tbody>
  <?php if (mysqli_num_rows($assigned)===0): ?>
    <tr><td colspan="6" class="empty"><div class="empty-icon">&#10003;</div>No students assigned to you yet.</td></tr>
  <?php else: while ($r = mysqli_fetch_assoc($assigned)): ?>
    <tr>
      <td><strong><?= e($r['s_code']) ?></strong></td>
      <td><?= e($r['s_name']) ?></td>
      <td><?= e($r['programme']) ?></td>
      <td><?= e($r['company_name']) ?></td>
      <td>
        <?php if ($r['a_id']): ?>
          <span class="badge badge-success">Done &middot; <?= e(number_format((float)$r['final_score'],2)) ?></span>
        <?php else: ?>
          <span class="badge badge-warning">Pending</span>
        <?php endif; ?>
      </td>
      <td>
        <div class="table-actions">
          <a class="btn btn-sm btn-primary" href="assessments.php?student=<?= (int)$r['sid'] ?>">
            <?= $r['a_id'] ? 'Edit marks' : 'Enter marks' ?>
          </a>
          <?php if ($r['a_id']): ?>
          <form method="POST" action="assessments.php" onsubmit="return confirmAction('Delete this assessment?');" style="display:inline;">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$r['a_id'] ?>">
            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
          </form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
  <?php endwhile; endif; ?>
  </tbody>
</table>
</div></div>
<?php include 'includes/shell_end.php'; ?>

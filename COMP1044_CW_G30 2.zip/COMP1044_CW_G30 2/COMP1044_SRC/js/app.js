// js/app.js - small client-side helpers (no localStorage, no frameworks)
function confirmAction(msg) { return window.confirm(msg || 'Are you sure?'); }

// Live recompute of assessment score on the assessment form
function recomputeScore() {
  var weights = {
    tasks_projects: 10, health_safety: 10, theory: 10,
    report_presentation: 15, language_clarity: 10,
    lifelong_learning: 15, project_management: 15, time_management: 15
  };
  var total = 0;
  for (var key in weights) {
    var inp = document.querySelector('[name="' + key + '"]');
    if (!inp) continue;
    var v = parseFloat(inp.value);
    if (isNaN(v) || v < 0 || v > 100) {
      inp.style.borderColor = inp.value !== '' ? '#b91c1c' : '';
      v = 0;
    } else {
      inp.style.borderColor = '';
    }
    var contribCell = document.querySelector('[data-contrib="' + key + '"]');
    var contrib = (v * weights[key]) / 100;
    if (contribCell) contribCell.textContent = contrib.toFixed(2);
    total += contrib;
  }
  var out = document.getElementById('finalScore');
  if (out) out.textContent = total.toFixed(2);
  var grade = document.getElementById('gradeLabel');
  if (grade) {
    var g = total >= 80 ? 'A' : total >= 70 ? 'B' : total >= 60 ? 'C' : total >= 50 ? 'D' : 'F';
    grade.textContent = g;
  }
}

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.assess-input').forEach(function (i) {
    i.addEventListener('input', recomputeScore);
  });
  if (document.getElementById('finalScore')) recomputeScore();
});

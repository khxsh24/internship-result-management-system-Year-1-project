-- =====================================================================
-- COMP1044 Coursework - Internship Result Management System
-- Database: COMP1044_CW
-- =====================================================================

CREATE DATABASE IF NOT EXISTS COMP1044_CW
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE COMP1044_CW;

-- ---------------------------------------------------------------------
-- Drop tables in reverse dependency order (for clean re-import)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS assessments;
DROP TABLE IF EXISTS internships;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;

-- ---------------------------------------------------------------------
-- USERS  (admins + assessors)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    role        ENUM('admin','assessor') NOT NULL DEFAULT 'assessor',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- STUDENTS
-- ---------------------------------------------------------------------
CREATE TABLE students (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    student_id  VARCHAR(20)  NOT NULL UNIQUE,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    programme   VARCHAR(100) NOT NULL,
    year        INT NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- INTERNSHIPS
-- Each student has one internship; assigned to an assessor (user).
-- ---------------------------------------------------------------------
CREATE TABLE internships (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    student_id    INT NOT NULL,
    company_name  VARCHAR(150) NOT NULL,
    position      VARCHAR(100) NOT NULL,
    start_date    DATE NOT NULL,
    end_date      DATE NOT NULL,
    assessor_id   INT NULL,
    CONSTRAINT fk_internship_student
        FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_internship_assessor
        FOREIGN KEY (assessor_id) REFERENCES users(id)    ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ASSESSMENTS
-- Marks per criterion (0-100). Final score is computed in PHP using:
--   tasks_projects 10%, health_safety 10%, theory 10%,
--   report_presentation 15%, language_clarity 10%,
--   lifelong_learning 15%, project_management 15%, time_management 15%
-- ---------------------------------------------------------------------
CREATE TABLE assessments (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    student_id           INT NOT NULL,
    assessor_id          INT NOT NULL,
    tasks_projects       DECIMAL(5,2) NOT NULL CHECK (tasks_projects       BETWEEN 0 AND 100),
    health_safety        DECIMAL(5,2) NOT NULL CHECK (health_safety        BETWEEN 0 AND 100),
    theory               DECIMAL(5,2) NOT NULL CHECK (theory               BETWEEN 0 AND 100),
    report_presentation  DECIMAL(5,2) NOT NULL CHECK (report_presentation  BETWEEN 0 AND 100),
    language_clarity     DECIMAL(5,2) NOT NULL CHECK (language_clarity     BETWEEN 0 AND 100),
    lifelong_learning    DECIMAL(5,2) NOT NULL CHECK (lifelong_learning    BETWEEN 0 AND 100),
    project_management   DECIMAL(5,2) NOT NULL CHECK (project_management   BETWEEN 0 AND 100),
    time_management      DECIMAL(5,2) NOT NULL CHECK (time_management      BETWEEN 0 AND 100),
    final_score          DECIMAL(5,2) NOT NULL,
    comments             TEXT NULL,
    updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_student_assessor (student_id, assessor_id),
    CONSTRAINT fk_assess_student
        FOREIGN KEY (student_id)  REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_assess_assessor
        FOREIGN KEY (assessor_id) REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- DEMO DATA
-- Passwords below are plain text matching the demo accounts shown on
-- the login page. In production use password_hash() / password_verify().
-- ---------------------------------------------------------------------
INSERT INTO users (name, email, password, role) VALUES
('System Admin',   'admin@uni.edu',  'admin123', 'admin'),
('Dr. Sarah Lim',  'sarah@uni.edu',  'pass123',  'assessor'),
('Dr. Ahmad Yusof','ahmad@uni.edu',  'pass123',  'assessor');

INSERT INTO students (student_id, name, email, programme, year) VALUES
('20231001', 'Aisha Rahman',    'aisha@student.uni.edu',  'BSc Computer Science', 3),
('20231002', 'Benjamin Tan',    'ben@student.uni.edu',    'BSc Software Eng.',    3),
('20231003', 'Chloe Lim',       'chloe@student.uni.edu',  'BSc Computer Science', 3),
('20231004', 'Daniel Ong',      'daniel@student.uni.edu', 'BSc Information Sys.', 3);

INSERT INTO internships (student_id, company_name, position, start_date, end_date, assessor_id) VALUES
(1, 'TechNova Sdn Bhd',   'Software Intern',  '2025-06-01', '2025-09-01', 2),
(2, 'CloudWorks',         'Backend Intern',   '2025-06-01', '2025-09-01', 2),
(3, 'DataPulse Analytics','Data Intern',      '2025-06-15', '2025-09-15', 3),
(4, 'GreenByte Studio',   'Web Intern',       '2025-07-01', '2025-10-01', 3);
